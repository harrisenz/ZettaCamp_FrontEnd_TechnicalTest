const findmedian = myarr => {
  const median = Math.floor(myarr.length / 2),
    nums = [...myarr].sort((x, y) => x - y);
  return myarr.length % 2 !== 0 ? nums[median] : (nums[median - 1] + nums[median]) / 2;
};
console.log('median array adalah :',findmedian([8, 7, 7, 9, 5, 4, 2, 9]));